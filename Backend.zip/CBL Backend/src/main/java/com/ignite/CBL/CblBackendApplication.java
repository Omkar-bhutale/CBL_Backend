package com.ignite.CBL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CblBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(CblBackendApplication.class, args);
    }

}
